package MyUDF;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

public class ISCLOSEDTO extends EvalFunc<String> {

	private static HashMap<String, double[]> parks = new HashMap<>();
	//between 1km to 2km
	private static double MIN_Distance = 0.01;
	
	@Override
	public String exec(Tuple a) throws IOException {
		if(a.get(0) == null || a.get(1) == null) return null;
		double longtitude = (double) a.get(0);
		double latitude = (double) a.get(1);
		String closestPark = "";
		double currentMin = Double.MAX_VALUE;
		if(parks.isEmpty()){
			FileReader fr = new FileReader("./public_art"); 
			BufferedReader d = new BufferedReader(fr); 
			String line;
			while((line = d.readLine()) != null) {
				try{
					String[] tokens = line.split(",");
					parks.put(tokens[0], new double[]{
					Double.parseDouble(tokens[tokens.length - 2]), Double.parseDouble(tokens[tokens.length - 1])});

				}
				catch (Exception e){}
			}
		}
		for(Map.Entry<String, double[]> e : parks.entrySet()){
			double distance = 
					Math.sqrt(
						(longtitude - e.getValue()[0]) * (longtitude - e.getValue()[0]) + 
						(latitude - e.getValue()[1]) * (latitude - e.getValue()[1])
					);
			if(distance <= MIN_Distance && distance <= currentMin) {
				closestPark = e.getKey();
			}
		}
		return closestPark;
	}
	
	@Override
	public List<String> getCacheFiles() {
	  List<String> list = new ArrayList<String>(1);
	  list.add("/user/chicago/input/Public_Art.csv#public_art");
	  return list;
	}
	
}
