package UDFQ4;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;


public class CloseToPlayground extends EvalFunc<String> {
	
	private static HashMap<String, ArrayList<String>> parks = new HashMap<>();
	//between 1km to 2km
	private static double MIN_Distance = 0.01;
	//define the sport facilities/playground of interest
	private static String[] kidsFacilities = {"BASEBALL","BASKETBALL",
		"FOOTBALL", "SOCCER","GOLF","GYMNASIUM",
		"HANDBALL","RAQUETBALL","ICESKATING","POOL","SOFTBALL",
		"TRACK","PLAYGROUND"};
	
	//helper function to determine if a facility name refers to a kids-related
	//facility, which is what we want to investigate in
	private boolean isKidsFacility(String facilityName) {
		if (facilityName == null) {
			return false;
		}
		for (String f : kidsFacilities) {
			//Since facility names are not constant, we only look for 
			//sports names rather than full-string match
			if (facilityName.indexOf(f)!=-1){
				return true;
			}
		}
		return false;
	}
	
	@Override
	public String exec(Tuple a) throws IOException {
		if(a.get(0) == null || a.get(1) == null) return null;
		double longititude = (double) a.get(0);
		double latitude = (double) a.get(1);
		String closestPark = "";
		double currentMin = Double.MAX_VALUE;
		if(parks.isEmpty()){
			FileReader fr = new FileReader("./facilities"); 
			BufferedReader d = new BufferedReader(fr); 
			String line = null;
			while((line = d.readLine()) != null) {
				//eliminate all-words rows (e.g. header)
				if (!line.matches("[0-9]+")){
					continue;
				}
				String[] tokens = line.split(",");
				String parkName = tokens[0];
				String facilityName = tokens[2];
				//process location cell, which is originally of form (long,lat)
				String location = tokens[tokens.length-2].replace("(","").trim()+
						"%"+tokens[tokens.length-1].replace(")","").trim();
				if (isKidsFacility(facilityName)) {
					if (parks.containsKey(parkName)) {
						//Add new longitude/latitude to park name
						ArrayList<String> locations = parks.get(parkName);
						locations.add(location);
						parks.put(parkName,locations);
					}else {
						ArrayList<String> locations = new ArrayList<String>();
						locations.add(location);
						parks.put(parkName, locations);
					}
				}
			}
		}
		for(Map.Entry<String, ArrayList<String>> e : parks.entrySet()){
			ArrayList<String> locations = e.getValue();
			for (String l :locations){
				//for each facility location in a given park, calculate its 
				//distance to the current crime record, return the park name
				//whose facility is closest to the crime
				String[] longlat = l.split("%");
				double parkLong = Double.parseDouble(longlat[0]);
				double parkLat = Double.parseDouble(longlat[1]);
				double distance = 
						Math.sqrt(
							(longititude - parkLong) * (longititude - parkLong) + 
							(latitude - parkLat) * (latitude - parkLat)
						);
				if(distance <= MIN_Distance && distance <= currentMin) {
					closestPark = e.getKey();
				}
			}
		}
		return closestPark;
	}
	
	@Override
	public List<String> getCacheFiles() {
	  List<String> list = new ArrayList<String>(1);
	  list.add("/user/student022/input/Facilities.csv#facilities");
	  return list;
	}
}
